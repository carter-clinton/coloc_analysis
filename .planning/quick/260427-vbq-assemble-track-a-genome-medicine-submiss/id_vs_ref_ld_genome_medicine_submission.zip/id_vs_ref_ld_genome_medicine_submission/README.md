# id-vs-ref-LD Genome Medicine Submission Bundle

This bundle accompanies the manuscript *Real-LD Re-Analysis of Curated
Cardiometabolic Pleiotropy Loci: Identity-LD Fine-Mapping Systematically
Inflates Cross-Trait Colocalization Evidence*, submitted to *Genome Medicine*
by Carter K. Clinton (NCSU ASHES Lab).

## Contents

```
id_vs_ref_ld_genome_medicine_submission/
├── README.md                                   # this file
├── LICENSE-CODE                                # MIT (covers scripts/)
├── LICENSE-MANUSCRIPT-AND-DATA                 # CC-BY-4.0 (manuscript+data)
├── CITATION.cff
├── manuscript/
│   ├── id-vs-ref-LD.md                          # source
│   └── id-vs-ref-LD.html (+ minimal.css)     # rendered
├── figures/                                    # 14 files (7 builders × {pdf,png})
│   ├── fig1a_pipeline_schematic.{pdf,png}
│   ├── fig1b_locus_panels.{pdf,png}
│   ├── fig2_cs_yield.{pdf,png}
│   ├── fig3_sh2b3_eur_collapse_forest.{pdf,png}
│   ├── fig5_variant_mech_scorecard.{pdf,png}
│   ├── fig_h3_ld_overlap_dose_response.{pdf,png}      # = Fig S7
│   └── fig_s2_paired_fit_structural_inflation.{pdf,png}
├── supplementary/                              # 9 TSV + 1 .md
│   ├── yield_redistribution.tsv
│   ├── pair_pp_h4_summary.tsv
│   ├── table3_admissible_pairs.tsv
│   ├── per_trait_pair_distribution.tsv
│   ├── eight_hub_fates.tsv
│   ├── table1_surviving_rows.tsv
│   ├── afr_distribution_summary.tsv
│   ├── table4_coloc_error_breakdown.tsv
│   ├── pathway_real_ld_disclosure.tsv
│   └── TRACK-A-FROZEN-NUMBERS.md
└── scripts/
    ├── R/
    │   ├── aggregators/                        # 3 R aggregators
    │   │   ├── aggregate_table3_admissible_pairs.R
    │   │   ├── aggregate_per_trait_pair_and_hubs.R
    │   │   └── aggregate_table1_pleiotropic_loci.R
    │   └── figures/                            # 7 R figure builders
    │       ├── fig1a_pipeline_schematic.R
    │       ├── fig1b_locus_panels.R
    │       ├── fig2_cs_yield.R
    │       ├── fig3_sh2b3_eur_collapse_forest.R
    │       ├── fig5_variant_mech_scorecard.R
    │       ├── fig_h3_ld_overlap_dose_response.R
    │       └── fig_s2_paired_fit_structural_inflation.R
    └── python/                                 # 3 Track-A Python aggregators
        ├── aggregate_coloc_manifest_errors.py
        ├── aggregate_pathway_results.py
        └── aggregate_qtl_coloc.py
```

## Source repository

The full pinned Snakemake pipeline (and the Track B work-in-progress, which is
*not* part of this submission) lives at:

  https://github.com/carter-clinton/coloc_analysis.git

This bundle is a curated, self-contained snapshot of just the Track A artefacts
needed to reproduce the manuscript figures and tables.

## Pre-registration

- Root pre-registration: https://osf.io/pvb5j
- M2 amendment / Phase 1 closeout PDF: https://osf.io/az52u

## Reproducibility

The script `bin/build_id_vs_ref_ld_submission_bundle.sh` in the source repository
regenerates this exact bundle from a clean checkout. To rebuild:

```bash
git clone https://github.com/carter-clinton/coloc_analysis.git
cd coloc_analysis
bin/build_id_vs_ref_ld_submission_bundle.sh
```

The output zip will appear at
`.planning/quick/260427-vbq-assemble-track-a-genome-medicine-submiss/id_vs_ref_ld_genome_medicine_submission.zip`.

## Author

Carter K. Clinton — NCSU ASHES Lab — ORCID: TODO (placeholder; replace before
journal upload).

## License

- Code (`scripts/`): MIT — see `LICENSE-CODE`.
- Manuscript and data (`manuscript/`, `figures/`, `supplementary/`):
  Creative Commons Attribution 4.0 International (CC-BY-4.0) — see
  `LICENSE-MANUSCRIPT-AND-DATA`.

## Build provenance

- Source commit:  fa03ad0f18f16bf55e67d60b92980456ac5b1e63
- Build date UTC: 2026-05-04T03:41:45Z
- Build host:     login03.hpc.ncsu.edu
- Manuscript render path: html:pandoc-fallback
