# ta-r3 Cowork handoff bundle — 2026-05-06

**Phase:** ta-r3-audit-v2-driven-psd-and-r1-refire
**HPC author:** Carter K. Clinton (NCSU ASHES Lab) via Claude Opus 4.7 GSD orchestration
**Bundle date:** 2026-05-06
**Manuscript md5 (locked; entry == exit):** `2a57c1a061f0c66988a55d1d6600efdf`
**Honest-framing lock:** "audit-driven re-analysis" — NOT "fix" / "revision" / "cleanup"

## Reading order

1. `HPC_DELIVERABLE_2026-05-06.md` — start here. Phase summary + decision tokens + commit hashes per wave + LSF job IDs + md5 invariants + Cowork-side TODO list + OSF disclosure paths.
2. `phase/ta-r3-VERIFICATION.md` and `phase/ta-r3-VERIFICATION-PHASE.md` — wave-level (W5-emitted) and orchestrator-issued goal verification.
3. `phase/ta-r3-CONTEXT.md` — all decision tokens at phase exit (D-TA-R3-OSF-COVERAGE / W1-FIRM / W2-STRUCTURAL / W3-FIRES + 0/6 / W4-DEFERRED_TO_FOOTNOTE / W5-PHASE-CLOSURE).
4. Per-wave `SUMMARY.md` files for the analytic narrative.
5. `osf/` for OSF amendment text + deviations log entry.

## Phase headline finding

The audit-V2 §HQ#2(i)/(ii)/(iii)/(g) reviewer concerns are addressed empirically. The Track A id-vs-ref-LD manuscript narrative survives unchanged. Manuscript md5 is byte-identical at phase entry and exit.

| Wave | Outcome | Reviewer concern | Disposition |
|---|---|---|---|
| W1 | `BRANCH_PSD_FIRM` | HQ#2(i) — PP≈1.0 from non-PSD LD + non-converged fits | Refuted at SH2B3. Primary λ=0.01: 5/5 EUR converged; 3/3 canonical pairs PP.H4=1.000 |
| W2 | `BRANCH_R1_STRUCTURAL` | HQ#2(iii) — fixes applied to SH2B3 only | Refuted. 28/28 R1 trait-pairs still empty after cache-invalidated re-fire under HEAD with `069b34f`+`7d54183`+`02c4404` ancestors |
| W3 | 0/6 surviving | HQ#2(iii) — selective firing | Refuted. Symmetric pipeline application across FTO/MC4R/APOL1/CXADR EUR yields 0/6 PP.H4≥0.8; SH2B3 is the only Tier-A survivor |
| W4 | `DEFERRED_TO_FOOTNOTE` | HQ#2(g) — 200-vs-224 row-count mismatch | Resolved via A9 footnote. Tier_assignments.tsv md5 untouched |
| W5 | `PHASE-CLOSURE` | All HPC-side audit items | 8 md5_baseline successor rows + VERIFICATION.md + this bundle |

## Bundle contents

```
ta-r3-cowork-handoff-2026-05-06/
├── README.md                                 (this file)
├── HPC_DELIVERABLE_2026-05-06.md             (primary handoff brief)
├── MANIFEST.sha256                           (sha256sum of every bundled file)
├── phase/                                    (planning artifacts)
│   ├── ta-r3-CONTEXT.md
│   ├── ta-r3-VERIFICATION.md                 (W5-emitted; D1-D13)
│   ├── ta-r3-VERIFICATION-PHASE.md           (orchestrator-issued)
│   ├── ta-r3-W{1,2,3,4,5}-*-PLAN.md          (5 plans)
│   ├── ta-r3-W{1,2,3,4,5}-*-SUMMARY.md       (5 wave summaries)
│   ├── ta-r3-W2-*.tsv|.txt                   (5 W2 forensic artifacts)
│   ├── ta-r3-W4-row-investigation.tsv        (HLA reconcile evidence)
│   └── md5_baseline.tsv                      (W7 baseline + 8 ta-r3 successor rows)
├── compute/
│   ├── W1/
│   │   ├── sh2b3_psd_pph4_summary.tsv        (3 pairs × 3 lambdas; 9 data rows)
│   │   ├── sh2b3_psd_ld_pathology.tsv        (negative_eig_pct=23.4637; v2-audit baseline)
│   │   └── fits/                             (15 PSD-regularized SuSiE-RSS .fit.rds)
│   ├── W2/
│   │   └── coloc_susie/                      (28 R1 trait-pair JSONs; cache-invalidated re-fire)
│   ├── W3/
│   │   ├── coloc_susie_R2/                   (15 JSONs: 9 SH2B3 + 6 W3)
│   │   ├── coloc_susie_R2_FTO/               (3 JSONs: bmi-htn, bmi-t2d, htn-t2d)
│   │   ├── coloc_susie_R2_MC4R/              (1 JSON: bmi-t2d)
│   │   ├── coloc_susie_R2_APOL1/             (1 JSON: htn-stroke)
│   │   ├── coloc_susie_R2_CXADR/             (1 JSON: bmi-htn)
│   │   └── coloc_manifest_R2.tsv             (15 rows; 9 SH2B3 baseline + 6 W3 parity)
│   ├── coloc_summary.tsv                     (rebuilt; 40 rows; post-W3 md5 073f8c05...)
│   └── tier_assignments.tsv                  (UNTOUCHED in W4; included for reference)
├── code/
│   ├── refit_sh2b3_psd_regularized.R         (W1 fitter; Wen 2017 ridge + Hutchinson 2020 eigclip)
│   ├── snp_id_bridge.R                       (W1 reusable variant-ID bridge utility)
│   ├── merge_r2_into_summary.R               (W3 R2 parity merge aggregator)
│   ├── fire_canonical_susie_pairs.sh         (W3 parameterized driver; --region + --ancestry)
│   ├── regions_curated.csv                   (W3-extended; 4 new EUR rows)
│   └── tests/
│       └── test_refit_sh2b3_psd_snp_id_bridge.R  (W1 failing-test-first regression)
├── osf/
│   ├── osf-amendment-r3-2026-05-04.md        (OSF amendment text; posting OVERRIDDEN locally)
│   ├── osf_deviations.md                     (project-wide OSF deviations log; W5 entry at end)
│   └── AUDIT-REVIEW-V2-2026-04-26.md         (v2 audit findings — what this phase responds to)
├── logs/                                     (LSF audit trail)
│   ├── sh2b3_psd_refit/                      (W1: dispatch.log + 30 .err/.out × original 15 + redispatch 12)
│   ├── ta_r3_W2_r1_refire/                   (W2 dispatch.log)
│   ├── ta_r3_W3_r2_parity/                   (W3 dispatch.log)
│   └── ta_r3_W4_hla_reconcile/               (W4 hla_reconcile.log)
└── manuscript/
    └── id-vs-ref-LD.md                       (locked at md5 2a57c1a061f0c66988a55d1d6600efdf)
```

## Cowork-side action items (from HPC_DELIVERABLE §"Cowork-side TODO list")

Listed here for convenience; full context in `HPC_DELIVERABLE_2026-05-06.md` lines 232-244.

1. **A1 / A2 / A3:** Manuscript text edits — frame as "audit-driven re-analysis" verbiage.
2. **A6 statistical formalization:** McNemar, bootstrap, BH-FDR per audit-V2 statistical recommendations.
3. **A7:** Redact internal-state-machine references in the manuscript.
4. **A8:** Promote Fig S2 to main-text Fig 4.
5. **A9 footnote:** Negative-control narrative — uses W4 DEFERRED_TO_FOOTNOTE prose recorded verbatim in `phase/ta-r3-CONTEXT.md`.
6. **v5 submission bundle ship:** Build via `bin/build_id_vs_ref_ld_submission_bundle.sh` against post-W5 disk numbers; SHA-256 manifest update; OSF deviation log entry; submit to *Genome Medicine* portal.
7. **OSF outcome-branch follow-up update:** Append realized W1-W4 outcomes to osf.io/az52u parent record.
8. **OSF amendment posting decision (D9 WARN):** Decide between (a) retroactive OSF posting + cover-letter timing footnote OR (b) v5 cover-letter pre-registration-timing limitation. Either path is rigor-defensible; option (a) is stricter.

## Verifying bundle integrity

```
cd ta-r3-cowork-handoff-2026-05-06/
sha256sum -c MANIFEST.sha256
```

All 158 files should report `OK`. If any FAIL, re-pull the bundle.
