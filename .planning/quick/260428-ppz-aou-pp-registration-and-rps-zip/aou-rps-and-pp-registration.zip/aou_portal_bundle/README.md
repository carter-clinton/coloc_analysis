# AoU Researcher Workbench Portal Bundle

This zip contains paste-ready Markdown documents for two distinct All of Us
Researcher Workbench portal actions:

1. **`AOU-WORKBENCH-REGISTRATION.md`** — workspace registration (Research
   Project Summary / RPS) sub-prompts. 13 portal sections matching the AoU
   RPS form 1:1. Paste section-by-section into the workspace creation flow.

2. **`AOU-PP-REGISTRATION.md`** — Publications & Presentations (P&P)
   draft registration paste-ready Markdown. Contains TWO stacked P&P
   registration blocks:
   - Block 1 — Track B → *Nature Genetics*
   - Block 2 — M3 → *Scientific Data* (data descriptor; venue locked
     2026-04-28 per DEC-2026-04-28-01)

## Paste order

1. Register the workspace first using `AOU-WORKBENCH-REGISTRATION.md`.
   Workspace setup precedes any P&P registration because the P&P record
   references the workspace.

2. After the workspace is approved, file BOTH P&P blocks in
   `AOU-PP-REGISTRATION.md` at draft stage. AoU policy
   (`.planning/amendments/AOU-LD-PIPELINE.md` §2 P6 + §12 R6) requires
   draft-stage P&P registration before any external submission.

3. Update each P&P record at every major scope change and again at submission
   with the final author list, journal name, and submission date.

## Lock-time decisions still TODO

- **AoU CDR Release version** — locked at workspace setup; populate
  `AOU-PP-REGISTRATION.md` §1.6 / §2.6 once decided.
- **ORCID** — populate Author tables in `AOU-PP-REGISTRATION.md` §1.2 / §2.2
  before any external submission. Same TODO carried in the Track A submission
  bundle's `CITATION.cff` (separate zip).
- **Final BMI EUR primary source** (Loh 2022 vs Yengo 2022 per
  `PROJECT.md` "Open human-action items" (b)) — affects Track B
  Methods text but does not block P&P draft registration.

## Char-limit handling

AoU portal field char limits vary. Trim each pasted section to the live
limit at paste time. The plain-language lay summary, methods summary, and
acknowledgments are the most likely fields to require trimming.

## Source provenance

| Field | Value |
|---|---|
| Source repository commit | `55af8fa83f2159b075d62540d68490b73d224c8f` |
| Bundle build date (UTC) | `2026-04-28T03:58:45Z` |
| Builder script | `bin/build_aou_portal_bundle.sh` |
| Quick task | quick-260428-ppz-aou-pp-registration-and-rps-zip |

## Re-build

From a clean checkout:

```bash
git clone <repo-url> coloc_analysis
cd coloc_analysis
bin/build_aou_portal_bundle.sh
# zip lands at .planning/quick/260428-ppz-aou-pp-registration-and-rps-zip/
#   aou-rps-and-pp-registration.zip
```

The bundle is fully regenerable from the source-of-truth Markdown files
under `.planning/quick/260426-aow-...` and `.planning/quick/260428-ppz-...`.
